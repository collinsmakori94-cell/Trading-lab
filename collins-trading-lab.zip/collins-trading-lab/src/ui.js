// ui.js
// Wires all DOM interactions: toolbar, sidebar, annotation placement flow,
// records list, statistics rendering, resizable panels, replay scrubber.

import { ANNOTATION_TYPES } from './annotations.js';
import { computeStatistics } from './statistics.js';

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

export class UI {
  /**
   * @param {Object} deps - { chart, annotations, replay, storage, getMeta, onLoadCSV, onModeChange }
   */
  constructor(deps) {
    this.chart = deps.chart;
    this.annotations = deps.annotations;
    this.replay = deps.replay;
    this.storage = deps.storage;
    this.getMeta = deps.getMeta;
    this.onLoadCSV = deps.onLoadCSV;
    this.onModeChange = deps.onModeChange;

    this.activeMode = null;   // { type, subtype }
    this.candles = [];

    this._bindTopbar();
    this._bindSidebar();
    this._bindModal();
    this._bindResizers();
    this._bindScrubber();
    this._bindStatsCollapse();

    this.annotations.onChange = () => {
      this._renderAnnotationList();
      this._renderPills();
    };

    this.refreshRecords();
    this.refreshStatistics();
  }

  // ============ TOPBAR ============
  _bindTopbar() {
    $('#csv-input').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file && this.onLoadCSV) this.onLoadCSV(file);
      e.target.value = '';
    });

    $('#btn-fit').addEventListener('click', () => this.chart.fitContent());
    $('#btn-reset-view').addEventListener('click', () => this.chart.fitContent());

    $('#mode-live').addEventListener('click', () => this.setMode('live'));
    $('#mode-replay').addEventListener('click', () => this.setMode('replay'));
  }

  setMode(mode) {
    $('#mode-live').classList.toggle('active', mode === 'live');
    $('#mode-replay').classList.toggle('active', mode === 'replay');
    $('#scrubber-wrap').classList.toggle('disabled', this.candles.length === 0);
    if (this.onModeChange) this.onModeChange(mode);
  }

  setFileMeta(text) {
    $('#file-meta').textContent = text;
  }

  showChartEmpty(show) {
    $('#chart-empty').style.display = show ? 'flex' : 'none';
  }

  setCandles(candles) {
    this.candles = candles;
    $('#scrub-total').textContent = String(candles.length).padStart(6, '0');
    $('#scrub-index').textContent = '000000';
    $('#scrubber-wrap').classList.remove('disabled');
    this._drawScrubberTrack();
  }

  updateOHLCReadout(candle) {
    if (!candle) return;
    $('#ohlc-o').textContent = fmtPrice(candle.open);
    $('#ohlc-h').textContent = fmtPrice(candle.high);
    $('#ohlc-l').textContent = fmtPrice(candle.low);
    $('#ohlc-c').textContent = fmtPrice(candle.close);
    $('#ohlc-t').textContent = fmtTime(candle.time);
  }

  // ============ SIDEBAR: TABS ============
  _bindSidebar() {
    $$('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.tab-btn').forEach(b => b.classList.remove('active'));
        $$('.tab-panel').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        $('#tab-' + btn.dataset.tab).classList.add('active');
      });
    });

    // Annotation pill buttons arm placement mode
    $$('.pill[data-annot]').forEach(pill => {
      pill.addEventListener('click', () => {
        const type = pill.dataset.annot;
        const sub = pill.dataset.sub;
        this._armMode(type, sub);
      });
    });

    $('#cancel-mode').addEventListener('click', () => this._disarmMode());

    $('#notes-input').addEventListener('input', (e) => {
      this.annotations.setNotes(e.target.value);
    });

    $('#btn-save-record').addEventListener('click', () => this._saveRecord());
    $('#btn-clear-annotations').addEventListener('click', () => {
      if (!this.annotations.hasAny()) return;
      this.annotations.reset();
      $('#notes-input').value = '';
      this._toast('Annotations cleared.');
    });

    $('#btn-export-json').addEventListener('click', () => this.storage.exportJSON());

    $('#import-json-input').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try {
        const text = await file.text();
        const added = this.storage.importJSON(text);
        this.refreshRecords();
        this.refreshStatistics();
        this._toast(`Imported ${added} record(s).`);
      } catch (err) {
        this._toast('Import failed: ' + err.message);
      }
    });
  }

  _armMode(type, subtype) {
    this.activeMode = { type, subtype };
    $('#active-mode-banner').style.display = 'block';
    $('#active-mode-label').textContent = subtype
      ? `${ANNOTATION_TYPES[type].label} — ${subtype}`
      : ANNOTATION_TYPES[type].label;
    this._renderPills();
  }

  _disarmMode() {
    this.activeMode = null;
    $('#active-mode-banner').style.display = 'none';
    this._renderPills();
  }

  _renderPills() {
    $$('.pill[data-annot]').forEach(pill => {
      const type = pill.dataset.annot;
      const sub = pill.dataset.sub;
      const armed = this.activeMode && this.activeMode.type === type && this.activeMode.subtype === sub;
      pill.classList.toggle('selected', !!armed);
    });
  }

  /** Called by app.js when a candle on the chart is clicked. */
  handleChartClick(candle, index) {
    if (!this.activeMode) return;
    this.annotations.place(this.activeMode.type, candle, index, this.activeMode.subtype);
    this._disarmMode();
    this._toast(`${ANNOTATION_TYPES[this.activeMode?.type]?.label || 'Annotation'} placed.`);
  }

  _renderAnnotationList() {
    const list = $('#annotation-list');
    const s = this.annotations.state;
    const rows = [];

    if (s.session) {
      rows.push(this._annotRow('session', `Session · ${s.session.subtype}`, `#${s.session.candleIndex}`, colorForSession(s.session.subtype)));
    }
    ['trendStart', 'trendEnd', 'trigger', 'entry'].forEach(type => {
      const a = s[type];
      if (a) rows.push(this._annotRow(type, ANNOTATION_TYPES[type].label, `#${a.candleIndex} · ${fmtPrice(a.price ?? '')}`, ANNOTATION_TYPES[type].color));
    });
    ['stopLoss', 'takeProfit'].forEach(type => {
      const a = s[type];
      if (a) rows.push(this._annotRow(type, ANNOTATION_TYPES[type].label, `#${a.candleIndex} · ${fmtPrice(a.price)}`, ANNOTATION_TYPES[type].color));
    });

    if (rows.length === 0) {
      list.innerHTML = '<p class="dim small">No annotations yet for this chart.</p>';
      return;
    }
    list.innerHTML = '';
    rows.forEach(r => list.appendChild(r));

    const rr = this.annotations.riskReward();
    $('#risk-hint').textContent = rr
      ? `Risk:Reward ≈ 1 : ${rr.toFixed(2)}`
      : 'Set entry, stop & target — R:R calculates automatically.';
  }

  _annotRow(type, label, detail, color) {
    const row = document.createElement('div');
    row.className = 'annot-row';
    row.innerHTML = `
      <div class="annot-main">
        <span class="swatch" style="background:${color}"></span>
        <span class="annot-label">${label}</span>
        <span class="annot-detail">${detail}</span>
      </div>
      <button class="annot-del" title="Delete">✕</button>
    `;
    row.querySelector('.annot-main').addEventListener('click', () => this._openEditModal(type));
    row.querySelector('.annot-del').addEventListener('click', (e) => {
      e.stopPropagation();
      this.annotations.remove(type);
    });
    return row;
  }

  // ============ EDIT MODAL ============
  _bindModal() {
    $('#edit-modal-cancel').addEventListener('click', () => this._closeModal());
    $('#edit-modal-overlay').addEventListener('click', (e) => {
      if (e.target.id === 'edit-modal-overlay') this._closeModal();
    });
  }

  _openEditModal(type) {
    const a = this.annotations.state[type];
    if (!a) return;
    this._editingType = type;

    $('#edit-modal-title').textContent = `Edit — ${type === 'session' ? 'Session' : ANNOTATION_TYPES[type].label}`;
    const body = $('#edit-modal-body');
    body.innerHTML = '';

    const idxField = fieldHTML('Candle Index', a.candleIndex, 'number', 'edit-idx');
    body.appendChild(idxField);

    if (type === 'session') {
      const sub = document.createElement('div');
      sub.innerHTML = `<label>Bias</label>`;
      const row = document.createElement('div');
      row.className = 'pill-row';
      ['bullish', 'bearish', 'range'].forEach(sv => {
        const b = document.createElement('button');
        b.className = 'pill' + (a.subtype === sv ? ' selected' : '');
        b.textContent = sv;
        b.type = 'button';
        b.addEventListener('click', () => {
          row.querySelectorAll('.pill').forEach(p => p.classList.remove('selected'));
          b.classList.add('selected');
          row.dataset.value = sv;
        });
        row.appendChild(b);
      });
      row.dataset.value = a.subtype;
      sub.appendChild(row);
      body.appendChild(sub);
      this._editSubtypeRow = row;
    } else if ('price' in a) {
      body.appendChild(fieldHTML('Price', a.price, 'number', 'edit-price', 'any'));
    }

    $('#edit-modal-delete').onclick = () => {
      this.annotations.remove(type);
      this._closeModal();
    };
    $('#edit-modal-save').onclick = () => {
      const patch = {};
      const idxInput = $('#edit-idx');
      if (idxInput) {
        const idx = parseInt(idxInput.value, 10);
        if (!Number.isNaN(idx) && this.candles[idx]) {
          patch.candleIndex = idx;
          patch.time = this.candles[idx].time;
        }
      }
      if (type === 'session') {
        patch.subtype = this._editSubtypeRow.dataset.value;
      } else {
        const priceInput = $('#edit-price');
        if (priceInput) {
          const p = parseFloat(priceInput.value);
          if (!Number.isNaN(p)) patch.price = p;
        }
      }
      this.annotations.update(type, patch);
      this._closeModal();
    };

    $('#edit-modal-overlay').classList.add('open');
  }

  _closeModal() {
    $('#edit-modal-overlay').classList.remove('open');
  }

  // ============ SAVE / RECORDS ============
  _saveRecord() {
    if (!this.annotations.hasAny()) {
      this._toast('Place at least one annotation before saving.');
      return;
    }
    const meta = this.getMeta();
    const record = this.annotations.toRecord(meta);
    this.storage.add(record);
    this.refreshRecords();
    this.refreshStatistics();
    this.annotations.reset();
    $('#notes-input').value = '';
    this._toast('Review record saved.');
  }

  refreshRecords() {
    const records = this.storage.getAll();
    $('#records-count').textContent = String(records.length);
    const list = $('#records-list');
    if (records.length === 0) {
      list.innerHTML = '<p class="dim small">No saved records yet.</p>';
      return;
    }
    list.innerHTML = '';
    [...records].reverse().forEach(r => {
      const card = document.createElement('div');
      card.className = 'record-card';
      const badge = r.session ? `<span class="record-badge ${r.session}">${r.session}</span>` : '';
      card.innerHTML = `
        <div class="record-card-top">
          <span class="record-symbol">${escapeHTML(r.symbol)} <span class="dim">${escapeHTML(r.timeframe)}</span></span>
          ${badge}
        </div>
        <div class="record-meta">
          idx ${r.candleIndex ?? '–'} · RR ${r.riskReward ? r.riskReward.toFixed(2) : '–'} · ${new Date(r.savedAt).toLocaleString()}
          <button class="record-del" title="Delete record">✕</button>
        </div>
      `;
      card.querySelector('.record-del').addEventListener('click', (e) => {
        e.stopPropagation();
        this.storage.remove(r.id);
        this.refreshRecords();
        this.refreshStatistics();
      });
      list.appendChild(card);
    });
  }

  refreshStatistics() {
    const stats = computeStatistics(this.storage.getAll());
    $('#stat-reviewed').textContent = stats.reviewed;
    $('#stat-bullish').textContent = stats.bullish;
    $('#stat-bearish').textContent = stats.bearish;
    $('#stat-range').textContent = stats.range;
    $('#stat-trendlen').textContent = stats.avgTrendLength ?? '–';
    $('#stat-pullback').textContent = stats.avgPullback ?? '–';
    $('#stat-winrate').textContent = stats.winRate === null ? '—' : `${stats.winRate}%`;
    $('#stat-rr').textContent = stats.avgRR ? `1 : ${stats.avgRR}` : '–';
  }

  // ============ RESIZERS ============
  _bindResizers() {
    const colResizer = $('#col-resizer');
    const sidebar = $('#sidebar');
    let dragging = false;
    colResizer.addEventListener('mousedown', () => { dragging = true; document.body.style.cursor = 'col-resize'; });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const w = window.innerWidth - e.clientX;
      sidebar.style.width = Math.min(Math.max(w, 220), 560) + 'px';
      this.chart.resize();
    });
    window.addEventListener('mouseup', () => { dragging = false; document.body.style.cursor = ''; });

    const rowResizer = $('#row-resizer');
    const statsPanel = $('#stats-panel');
    let draggingRow = false;
    rowResizer.addEventListener('mousedown', () => { draggingRow = true; document.body.style.cursor = 'row-resize'; });
    window.addEventListener('mousemove', (e) => {
      if (!draggingRow) return;
      const h = window.innerHeight - e.clientY;
      statsPanel.style.height = Math.min(Math.max(h, 46), 340) + 'px';
      this.chart.resize();
    });
    window.addEventListener('mouseup', () => { draggingRow = false; document.body.style.cursor = ''; });
  }

  _bindStatsCollapse() {
    $('#stats-collapse').addEventListener('click', () => {
      const panel = $('#stats-panel');
      panel.classList.toggle('collapsed');
      $('#stats-collapse').textContent = panel.classList.contains('collapsed') ? '⌃' : '⌄';
      this.chart.resize();
    });
  }

  // ============ SCRUBBER ============
  _bindScrubber() {
    $('#scrub-back').addEventListener('click', () => this.replay.stepBackward());
    $('#scrub-fwd').addEventListener('click', () => this.replay.stepForward());
    $('#scrub-play').addEventListener('click', () => this.replay.togglePlay());
    $('#scrub-speed').addEventListener('change', (e) => this.replay.setSpeed(parseInt(e.target.value, 10)));

    const track = $('#scrub-track');
    track.addEventListener('click', (e) => {
      if (!this.replay.active || this.candles.length === 0) return;
      const rect = track.getBoundingClientRect();
      const ratio = (e.clientX - rect.left) / rect.width;
      const idx = Math.round(ratio * (this.candles.length - 1));
      this.replay.jumpTo(idx);
    });

    window.addEventListener('resize', () => this._drawScrubberTrack());
  }

  onReplayStep(index, total) {
    $('#scrub-index').textContent = String(Math.max(index, 0)).padStart(6, '0');
    $('#scrub-total').textContent = String(total).padStart(6, '0');
    const ratio = total > 1 ? index / (total - 1) : 0;
    const wrap = $('.scrub-track-wrap');
    $('#scrub-playhead').style.left = (ratio * wrap.clientWidth) + 'px';
  }

  onReplayPlayStateChange(isPlaying) {
    $('#scrub-play').textContent = isPlaying ? '⏸' : '▶';
  }

  _drawScrubberTrack() {
    const canvas = $('#scrub-track');
    const wrap = $('.scrub-track-wrap');
    const dpr = window.devicePixelRatio || 1;
    const w = wrap.clientWidth, h = 34;
    canvas.width = w * dpr; canvas.height = h * dpr;
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#161a22';
    ctx.fillRect(0, 0, w, h);

    if (this.candles.length === 0) return;
    // baseline
    ctx.strokeStyle = '#262b35';
    ctx.beginPath();
    ctx.moveTo(0, h / 2); ctx.lineTo(w, h / 2); ctx.stroke();

    // annotation ticks from currently saved records that reference this dataset's indices
    const s = this.annotations.state;
    const total = this.candles.length;
    const tickAt = (idx, color) => {
      if (idx === null || idx === undefined) return;
      const x = (idx / Math.max(total - 1, 1)) * w;
      ctx.fillStyle = color;
      ctx.fillRect(Math.max(0, x - 1), 4, 2, h - 8);
    };
    if (s.session) tickAt(s.session.candleIndex, '#f2a33c');
    if (s.trendStart) tickAt(s.trendStart.candleIndex, '#4fa3e3');
    if (s.trendEnd) tickAt(s.trendEnd.candleIndex, '#4fa3e3');
    if (s.trigger) tickAt(s.trigger.candleIndex, '#c792ea');
    if (s.entry) tickAt(s.entry.candleIndex, '#2fbf8f');
  }

  // ============ TOAST ============
  _toast(message) {
    const el = $('#toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
  }
}

function fieldHTML(label, value, type, id, step) {
  const wrap = document.createElement('div');
  wrap.innerHTML = `<label>${label}</label><input type="${type}" id="${id}" value="${value ?? ''}" ${step ? `step="${step}"` : ''} />`;
  return wrap;
}

function fmtPrice(v) {
  if (v === '' || v === undefined || v === null || Number.isNaN(v)) return '–';
  return Number(v).toFixed(5).replace(/0+$/, '').replace(/\.$/, '');
}

function fmtTime(unixSeconds) {
  const d = new Date(unixSeconds * 1000);
  return d.toISOString().replace('T', ' ').slice(0, 16);
}

function colorForSession(sub) {
  return { bullish: '#2fbf8f', bearish: '#e5484d', range: '#f2a33c' }[sub] || '#f2a33c';
}

function escapeHTML(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
