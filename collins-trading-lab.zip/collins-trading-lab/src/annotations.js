// annotations.js
// Manages the annotation set for the currently loaded chart, and renders
// them onto the chart as markers / price lines.

export const ANNOTATION_TYPES = {
  session:    { label: 'Session',       color: '#f2a33c', shape: 'circle' },
  trendStart: { label: 'Trend Start',   color: '#4fa3e3', shape: 'arrowUp' },
  trendEnd:   { label: 'Trend End',     color: '#4fa3e3', shape: 'arrowDown' },
  trigger:    { label: 'Trigger',       color: '#c792ea', shape: 'circle' },
  entry:      { label: 'Entry',         color: '#2fbf8f', shape: 'arrowUp' },
  stopLoss:   { label: 'Stop Loss',     color: '#e5484d', shape: 'square' },
  takeProfit: { label: 'Take Profit',   color: '#2fbf8f', shape: 'square' },
};

const SESSION_COLORS = {
  bullish: '#2fbf8f',
  bearish: '#e5484d',
  range: '#f2a33c',
};

function emptyState() {
  return {
    session: null,      // { candleIndex, time, subtype: 'bullish'|'bearish'|'range' }
    trendStart: null,   // { candleIndex, time, price }
    trendEnd: null,
    trigger: null,
    entry: null,
    stopLoss: null,     // { candleIndex, time, price }
    takeProfit: null,
    notes: '',
  };
}

export class AnnotationManager {
  /** @param {import('./chart.js').ChartWrapper} chartWrapper */
  constructor(chartWrapper) {
    this.chart = chartWrapper;
    this.state = emptyState();
    this.onChange = null; // callback set by ui.js
  }

  reset() {
    this.state = emptyState();
    this.render();
    this._notify();
  }

  hasAny() {
    return Object.entries(this.state).some(([k, v]) => k !== 'notes' && v);
  }

  /**
   * Place/overwrite an annotation using a clicked candle.
   * @param {string} type - key of ANNOTATION_TYPES
   * @param {Object} candle
   * @param {number} index
   * @param {string} [subtype] - for 'session': bullish|bearish|range
   */
  place(type, candle, index, subtype) {
    if (type === 'session') {
      this.state.session = { candleIndex: index, time: candle.time, subtype };
    } else if (type === 'stopLoss' || type === 'takeProfit') {
      // default price to candle low (stop) / high (target); user can fine-tune via edit modal
      const price = type === 'stopLoss' ? candle.low : candle.high;
      this.state[type] = { candleIndex: index, time: candle.time, price };
    } else {
      this.state[type] = { candleIndex: index, time: candle.time, price: candle.close };
    }
    this.render();
    this._notify();
  }

  update(type, patch) {
    if (!this.state[type]) return;
    Object.assign(this.state[type], patch);
    this.render();
    this._notify();
  }

  remove(type) {
    this.state[type] = null;
    this.render();
    this._notify();
  }

  setNotes(text) {
    this.state.notes = text;
  }

  _notify() {
    if (this.onChange) this.onChange(this.state);
  }

  /** Redraw markers & price lines on the chart from current state. */
  render() {
    const markers = [];
    const s = this.state;

    if (s.session) {
      markers.push({
        time: s.session.time,
        position: 'aboveBar',
        color: SESSION_COLORS[s.session.subtype] || '#f2a33c',
        shape: 'circle',
        text: `Session: ${s.session.subtype}`,
      });
    }
    if (s.trendStart) {
      markers.push({ time: s.trendStart.time, position: 'belowBar', color: '#4fa3e3', shape: 'arrowUp', text: 'Trend Start' });
    }
    if (s.trendEnd) {
      markers.push({ time: s.trendEnd.time, position: 'aboveBar', color: '#4fa3e3', shape: 'arrowDown', text: 'Trend End' });
    }
    if (s.trigger) {
      markers.push({ time: s.trigger.time, position: 'belowBar', color: '#c792ea', shape: 'circle', text: 'Trigger' });
    }
    if (s.entry) {
      markers.push({ time: s.entry.time, position: 'belowBar', color: '#2fbf8f', shape: 'arrowUp', text: 'Entry' });
    }

    this.chart.setMarkers(markers);

    if (s.stopLoss) this.chart.setPriceLine('stopLoss', s.stopLoss.price, '#e5484d', 'SL');
    else this.chart.removePriceLine('stopLoss');

    if (s.takeProfit) this.chart.setPriceLine('takeProfit', s.takeProfit.price, '#2fbf8f', 'TP');
    else this.chart.removePriceLine('takeProfit');
  }

  /** Compute risk:reward ratio from entry/stop/takeProfit if all present. */
  riskReward() {
    const { entry, stopLoss, takeProfit } = this.state;
    if (!entry || !stopLoss || !takeProfit) return null;
    const risk = Math.abs(entry.price - stopLoss.price);
    const reward = Math.abs(takeProfit.price - entry.price);
    if (risk === 0) return null;
    return reward / risk;
  }

  /** Build a database record from current state + chart metadata. */
  toRecord(meta) {
    const s = this.state;
    return {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      savedAt: new Date().toISOString(),
      symbol: meta.symbol || 'UNKNOWN',
      timeframe: meta.timeframe || '',
      date: meta.date || '',
      candleIndex: s.entry ? s.entry.candleIndex : (s.trigger ? s.trigger.candleIndex : null),
      session: s.session ? s.session.subtype : null,
      trendStart: s.trendStart ? s.trendStart.candleIndex : null,
      trendEnd: s.trendEnd ? s.trendEnd.candleIndex : null,
      trigger: s.trigger ? s.trigger.candleIndex : null,
      entry: s.entry ? { candleIndex: s.entry.candleIndex, price: s.entry.price } : null,
      stop: s.stopLoss ? { candleIndex: s.stopLoss.candleIndex, price: s.stopLoss.price } : null,
      takeProfit: s.takeProfit ? { candleIndex: s.takeProfit.candleIndex, price: s.takeProfit.price } : null,
      riskReward: this.riskReward(),
      notes: s.notes || '',
    };
  }
}
