// statistics.js
// Aggregates saved review records into summary statistics.

/**
 * @param {Array} records - review records from storage.js
 * @returns {Object} stats
 */
export function computeStatistics(records) {
  const stats = {
    reviewed: records.length,
    bullish: 0,
    bearish: 0,
    range: 0,
    avgTrendLength: null,
    avgPullback: null,
    winRate: null, // reserved for future outcome tracking
    avgRR: null,
  };

  if (records.length === 0) return stats;

  let trendLenSum = 0, trendLenCount = 0;
  let pullbackSum = 0, pullbackCount = 0;
  let rrSum = 0, rrCount = 0;

  for (const r of records) {
    if (r.session === 'bullish') stats.bullish++;
    else if (r.session === 'bearish') stats.bearish++;
    else if (r.session === 'range') stats.range++;

    // Trend length = candles between trendStart and trendEnd
    if (typeof r.trendStart === 'number' && typeof r.trendEnd === 'number') {
      const len = Math.abs(r.trendEnd - r.trendStart);
      if (len > 0) { trendLenSum += len; trendLenCount++; }
    }

    // Pullback = candles between trigger and entry (the retrace before continuation)
    if (typeof r.trigger === 'number' && r.entry && typeof r.entry.candleIndex === 'number') {
      const pb = Math.abs(r.entry.candleIndex - r.trigger);
      pullbackSum += pb; pullbackCount++;
    }

    if (typeof r.riskReward === 'number' && isFinite(r.riskReward)) {
      rrSum += r.riskReward; rrCount++;
    }
  }

  stats.avgTrendLength = trendLenCount ? +(trendLenSum / trendLenCount).toFixed(1) : null;
  stats.avgPullback = pullbackCount ? +(pullbackSum / pullbackCount).toFixed(1) : null;
  stats.avgRR = rrCount ? +(rrSum / rrCount).toFixed(2) : null;

  // Win rate is reserved for a future module that tracks trade outcomes
  // (e.g. by walking forward from entry to see whether stop or target hit first).
  stats.winRate = null;

  return stats;
}
