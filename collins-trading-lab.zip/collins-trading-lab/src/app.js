// app.js
// Application entry point. Wires csvLoader -> chart -> annotations -> replay -> storage -> ui.
//
// FUTURE EXPANSION NOTE:
// This module is intentionally the only place that owns cross-module state
// (the loaded candle dataset + symbol/timeframe/date meta). Future modules —
// Rule Discovery Engine, AI Prediction Engine, EA Generator, Pattern Matching,
// Strategy Version Control — should be added as new files under /src that
// import from storage.js (for the saved review-record database) and/or
// chart.js (for chart access), and are instantiated here alongside the
// existing modules. They should not need to modify csvLoader, chart,
// annotations, replay, storage or ui — only consume their public APIs.

import { loadCSVFile } from './csvLoader.js';
import { ChartWrapper } from './chart.js';
import { AnnotationManager } from './annotations.js';
import { ReplayController } from './replay.js';
import { Storage } from './storage.js';
import { UI } from './ui.js';

class App {
  constructor() {
    this.candles = [];
    this.meta = { symbol: '', timeframe: 'H1', date: '' };

    const container = document.getElementById('chart-container');
    this.chart = new ChartWrapper(container, {
      onCrosshairMove: (candle) => this.ui.updateOHLCReadout(candle),
      onClick: (candle, index) => this.ui.handleChartClick(candle, index),
    });

    this.annotations = new AnnotationManager(this.chart);

    this.replay = new ReplayController(this.chart, {
      onStep: (index, total) => this.ui.onReplayStep(index, total),
      onPlayStateChange: (playing) => this.ui.onReplayPlayStateChange(playing),
    });

    this.storage = new Storage();

    this.ui = new UI({
      chart: this.chart,
      annotations: this.annotations,
      replay: this.replay,
      storage: this.storage,
      getMeta: () => this._buildMeta(),
      onLoadCSV: (file) => this.handleLoadCSV(file),
      onModeChange: (mode) => this.handleModeChange(mode),
    });

    document.getElementById('symbol-input').addEventListener('input', (e) => {
      this.meta.symbol = e.target.value.trim().toUpperCase();
    });
    document.getElementById('timeframe-input').addEventListener('change', (e) => {
      this.meta.timeframe = e.target.value;
    });
  }

  async handleLoadCSV(file) {
    this.ui.setFileMeta('Parsing…');
    try {
      const candles = await loadCSVFile(file);
      this.candles = candles;
      this.chart.setData(candles);
      this.chart.fitContent();
      this.annotations.reset();
      this.replay.stop();

      const guessedSymbol = guessSymbolFromFilename(file.name);
      if (guessedSymbol && !document.getElementById('symbol-input').value) {
        document.getElementById('symbol-input').value = guessedSymbol;
        this.meta.symbol = guessedSymbol;
      }

      const first = candles[0], last = candles[candles.length - 1];
      this.meta.date = `${isoDate(first.time)} → ${isoDate(last.time)}`;

      this.ui.setFileMeta(`${file.name} · ${candles.length.toLocaleString()} candles · ${this.meta.date}`);
      this.ui.setCandles(candles);
      this.ui.showChartEmpty(false);
    } catch (err) {
      console.error(err);
      this.ui.setFileMeta('Failed to load CSV');
      this.ui._toast('Error: ' + err.message);
    }
  }

  handleModeChange(mode) {
    if (this.candles.length === 0) return;
    if (mode === 'replay') {
      this.replay.start(this.candles, Math.min(50, this.candles.length));
    } else {
      this.replay.stop();
    }
  }

  _buildMeta() {
    return {
      symbol: document.getElementById('symbol-input').value.trim() || 'UNKNOWN',
      timeframe: document.getElementById('timeframe-input').value,
      date: this.meta.date,
    };
  }
}

function isoDate(unixSeconds) {
  return new Date(unixSeconds * 1000).toISOString().slice(0, 10);
}

function guessSymbolFromFilename(name) {
  const m = name.match(/^([A-Za-z0-9]{3,12})/);
  return m ? m[1].toUpperCase() : '';
}

window.addEventListener('DOMContentLoaded', () => {
  window.__ctlApp = new App();
});
