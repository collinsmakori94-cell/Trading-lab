// replay.js
// Controls step-by-step reveal of candles for replay/backtesting review.

export class ReplayController {
  /**
   * @param {import('./chart.js').ChartWrapper} chartWrapper
   * @param {Object} callbacks - { onStep(index, total), onPlayStateChange(isPlaying) }
   */
  constructor(chartWrapper, callbacks = {}) {
    this.chart = chartWrapper;
    this.callbacks = callbacks;
    this.total = 0;
    this.index = -1;       // last revealed candle index (-1 = nothing revealed)
    this.active = false;
    this.playing = false;
    this.timer = null;
    this.intervalMs = 400;
  }

  /** Enter replay mode: hide all candles beyond a small warm-up window. */
  start(candles, warmup = 50) {
    this.total = candles.length;
    this.active = true;
    this.playing = false;
    this.index = Math.min(Math.max(warmup, 1), this.total) - 1;
    this.chart.setVisibleCount(this.index + 1);
    this.chart.fitContent();
    this._emit();
  }

  /** Exit replay mode: reveal full dataset. */
  stop() {
    this.active = false;
    this.pause();
    this.chart.setVisibleCount(null);
    this.chart.fitContent();
  }

  stepForward() {
    if (!this.active || this.index >= this.total - 1) {
      this.pause();
      return;
    }
    this.index += 1;
    this.chart.revealNext(this.index);
    this._emit();
  }

  stepBackward() {
    if (!this.active || this.index <= 0) return;
    this.index -= 1;
    this.chart.setVisibleCount(this.index + 1);
    this._emit();
  }

  jumpTo(index) {
    if (!this.active) return;
    this.index = Math.max(0, Math.min(index, this.total - 1));
    this.chart.setVisibleCount(this.index + 1);
    this._emit();
  }

  play() {
    if (!this.active || this.playing) return;
    this.playing = true;
    if (this.callbacks.onPlayStateChange) this.callbacks.onPlayStateChange(true);
    this.timer = setInterval(() => {
      if (this.index >= this.total - 1) {
        this.pause();
        return;
      }
      this.stepForward();
    }, this.intervalMs);
  }

  pause() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.playing && this.callbacks.onPlayStateChange) this.callbacks.onPlayStateChange(false);
    this.playing = false;
  }

  togglePlay() {
    this.playing ? this.pause() : this.play();
  }

  setSpeed(ms) {
    this.intervalMs = ms;
    if (this.playing) {
      this.pause();
      this.play();
    }
  }

  _emit() {
    if (this.callbacks.onStep) this.callbacks.onStep(this.index, this.total);
  }
}
