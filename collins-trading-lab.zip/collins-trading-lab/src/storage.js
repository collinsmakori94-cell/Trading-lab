// storage.js
// Persists annotation "review records" locally as JSON, using localStorage.
// Designed so a future module (e.g. a real backend, IndexedDB, or sync layer)
// can swap in behind the same interface.

const DB_KEY = 'ctl_review_records_v1';

export class Storage {
  constructor() {
    this.records = this._load();
  }

  _load() {
    try {
      const raw = localStorage.getItem(DB_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.warn('Collins Trading Lab: failed to read local database, starting fresh.', e);
      return [];
    }
  }

  _persist() {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(this.records));
    } catch (e) {
      console.error('Collins Trading Lab: failed to persist database.', e);
    }
  }

  getAll() {
    return this.records;
  }

  add(record) {
    this.records.push(record);
    this._persist();
    return record;
  }

  remove(id) {
    this.records = this.records.filter(r => r.id !== id);
    this._persist();
  }

  clear() {
    this.records = [];
    this._persist();
  }

  exportJSON() {
    const blob = new Blob([JSON.stringify(this.records, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `collins-trading-lab-records-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  importJSON(fileTextOrArray) {
    let incoming;
    if (typeof fileTextOrArray === 'string') {
      incoming = JSON.parse(fileTextOrArray);
    } else {
      incoming = fileTextOrArray;
    }
    if (!Array.isArray(incoming)) throw new Error('Imported file must contain a JSON array of records.');

    const existingIds = new Set(this.records.map(r => r.id));
    let added = 0;
    for (const rec of incoming) {
      if (rec && rec.id && !existingIds.has(rec.id)) {
        this.records.push(rec);
        existingIds.add(rec.id);
        added++;
      }
    }
    this._persist();
    return added;
  }
}
