// chart.js
// Thin wrapper around TradingView Lightweight Charts for candlestick rendering,
// crosshair readout, markers and price lines.

export class ChartWrapper {
  /**
   * @param {HTMLElement} container
   * @param {Object} callbacks - { onCrosshairMove(candle), onClick(candle, index) }
   */
  constructor(container, callbacks = {}) {
    this.container = container;
    this.callbacks = callbacks;
    this.candles = [];          // full dataset
    this.visibleCount = null;   // for replay mode; null = show all

    this.chart = LightweightCharts.createChart(container, {
      layout: {
        background: { type: 'solid', color: '#0a0c10' },
        textColor: '#8b93a4',
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: '#161a22' },
        horzLines: { color: '#161a22' },
      },
      crosshair: {
        mode: LightweightCharts.CrosshairMode.Normal,
        vertLine: { color: '#f2a33c', width: 1, style: 3, labelBackgroundColor: '#f2a33c' },
        horzLine: { color: '#f2a33c', width: 1, style: 3, labelBackgroundColor: '#f2a33c' },
      },
      rightPriceScale: {
        borderColor: '#262b35',
        scaleMargins: { top: 0.08, bottom: 0.2 },
      },
      timeScale: {
        borderColor: '#262b35',
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 6,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
      autoSize: true,
    });

    this.series = this.chart.addCandlestickSeries({
      upColor: '#2fbf8f',
      downColor: '#e5484d',
      borderUpColor: '#2fbf8f',
      borderDownColor: '#e5484d',
      wickUpColor: '#2fbf8f',
      wickDownColor: '#e5484d',
    });

    this.volumeSeries = this.chart.addHistogramSeries({
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
      color: '#3a4150',
    });
    this.chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 },
    });

    this._priceLines = {}; // key -> priceLine handle

    this.chart.subscribeCrosshairMove(param => {
      if (!param || !param.time || !this.callbacks.onCrosshairMove) return;
      const idx = this._timeToIndex.get(param.time);
      if (idx === undefined) return;
      this.callbacks.onCrosshairMove(this.candles[idx], idx);
    });

    this.chart.subscribeClick(param => {
      if (!param || !param.time || !this.callbacks.onClick) return;
      const idx = this._timeToIndex.get(param.time);
      if (idx === undefined) return;
      this.callbacks.onClick(this.candles[idx], idx);
    });

    this._resizeObserver = new ResizeObserver(() => {
      this.chart.applyOptions({ width: container.clientWidth, height: container.clientHeight });
    });
    this._resizeObserver.observe(container);
  }

  /** Load a full dataset (replaces any existing data). */
  setData(candles) {
    this.candles = candles;
    this._timeToIndex = new Map();
    candles.forEach((c, i) => this._timeToIndex.set(c.time, i));
    this.visibleCount = null;
    this.series.setData(candles);
    this.volumeSeries.setData(candles.map(c => ({
      time: c.time,
      value: c.volume,
      color: c.close >= c.open ? 'rgba(47,191,143,0.4)' : 'rgba(229,72,77,0.4)',
    })));
    this.clearMarkers();
    this.clearPriceLines();
  }

  fitContent() {
    this.chart.timeScale().fitContent();
  }

  /** Restrict visible candles to the first `count` (replay mode). count=null shows all. */
  setVisibleCount(count) {
    this.visibleCount = count;
    if (count === null) {
      this.series.setData(this.candles);
      this.volumeSeries.setData(this._volumeData(this.candles));
    } else {
      const slice = this.candles.slice(0, count);
      this.series.setData(slice);
      this.volumeSeries.setData(this._volumeData(slice));
    }
  }

  /** Append a single candle (efficient forward replay step). */
  revealNext(index) {
    const c = this.candles[index];
    if (!c) return;
    this.series.update(c);
    this.volumeSeries.update({
      time: c.time, value: c.volume,
      color: c.close >= c.open ? 'rgba(47,191,143,0.4)' : 'rgba(229,72,77,0.4)',
    });
    this.visibleCount = index + 1;
  }

  _volumeData(slice) {
    return slice.map(c => ({
      time: c.time, value: c.volume,
      color: c.close >= c.open ? 'rgba(47,191,143,0.4)' : 'rgba(229,72,77,0.4)',
    }));
  }

  scrollToRealtime() {
    this.chart.timeScale().scrollToRealTime();
  }

  setMarkers(markers) {
    // markers: [{ time, position, color, shape, text, id }]
    this.series.setMarkers(markers.sort((a, b) => a.time - b.time));
  }

  clearMarkers() {
    this.series.setMarkers([]);
  }

  setPriceLine(key, price, color, title) {
    this.removePriceLine(key);
    this._priceLines[key] = this.series.createPriceLine({
      price, color, lineWidth: 2, lineStyle: LightweightCharts.LineStyle.Dashed,
      axisLabelVisible: true, title,
    });
  }

  removePriceLine(key) {
    if (this._priceLines[key]) {
      this.series.removePriceLine(this._priceLines[key]);
      delete this._priceLines[key];
    }
  }

  clearPriceLines() {
    Object.keys(this._priceLines).forEach(k => this.removePriceLine(k));
  }

  scrollToIndex(index) {
    const c = this.candles[index];
    if (!c) return;
    this.chart.timeScale().scrollToPosition(0, false);
    this.chart.timeScale().setVisibleRange({
      from: this.candles[Math.max(0, index - 60)].time,
      to: c.time,
    });
  }

  resize() {
    this.chart.applyOptions({ width: this.container.clientWidth, height: this.container.clientHeight });
  }

  destroy() {
    this._resizeObserver.disconnect();
    this.chart.remove();
  }
}
