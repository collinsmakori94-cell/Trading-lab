// csvLoader.js
// Parses MetaTrader 5 CSV exports into a normalized candle array.
// Handles comma, semicolon and tab delimited files, with or without headers,
// and both "<DATE> <TIME>" split columns and single combined datetime columns.

/**
 * @typedef {Object} Candle
 * @property {number} time   - unix timestamp in seconds (UTC)
 * @property {number} open
 * @property {number} high
 * @property {number} low
 * @property {number} close
 * @property {number} volume
 */

const DELIMS = [',', ';', '\t'];

function detectDelimiter(sampleLine) {
  let best = ',';
  let bestCount = -1;
  for (const d of DELIMS) {
    const count = sampleLine.split(d).length;
    if (count > bestCount) {
      bestCount = count;
      best = d;
    }
  }
  return best;
}

function stripQuotes(s) {
  return s.replace(/^["']|["']$/g, '').trim();
}

// Try a handful of common MT5 date/time formats.
function parseDateTime(dateStr, timeStr) {
  dateStr = stripQuotes(dateStr || '');
  timeStr = stripQuotes(timeStr || '');

  let y, mo, d;
  let sepMatch = dateStr.match(/^(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})$/);
  if (sepMatch) {
    y = +sepMatch[1]; mo = +sepMatch[2]; d = +sepMatch[3];
  } else {
    sepMatch = dateStr.match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
    if (sepMatch) {
      d = +sepMatch[1]; mo = +sepMatch[2]; y = +sepMatch[3];
    }
  }
  if (y === undefined) return null;

  let hh = 0, mm = 0, ss = 0;
  if (timeStr) {
    const tMatch = timeStr.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (tMatch) {
      hh = +tMatch[1]; mm = +tMatch[2]; ss = tMatch[3] ? +tMatch[3] : 0;
    }
  }

  const ms = Date.UTC(y, mo - 1, d, hh, mm, ss);
  return Math.floor(ms / 1000);
}

/**
 * Identify column roles from a header row (case-insensitive, MT5 style: <DATE> <TIME> <OPEN> ...)
 */
function mapHeader(headerCells) {
  const map = {};
  headerCells.forEach((raw, i) => {
    const c = raw.replace(/[<>]/g, '').trim().toLowerCase();
    if (['date'].includes(c)) map.date = i;
    else if (['time'].includes(c)) map.time = i;
    else if (['datetime', 'date_time', 'timestamp'].includes(c)) map.datetime = i;
    else if (['open'].includes(c)) map.open = i;
    else if (['high'].includes(c)) map.high = i;
    else if (['low'].includes(c)) map.low = i;
    else if (['close'].includes(c)) map.close = i;
    else if (['tickvol', 'tick_volume', 'volume', 'vol'].includes(c)) {
      if (map.volume === undefined) map.volume = i;
    } else if (['real_volume'].includes(c)) {
      map.volume = i; // prefer real volume if present
    }
  });
  return map;
}

function looksLikeHeader(cells) {
  return cells.some(c => /[a-zA-Z]/.test(c));
}

/**
 * Parse raw CSV text into an array of Candle objects, sorted ascending by time,
 * with duplicate timestamps collapsed (last wins).
 * @param {string} text
 * @returns {Candle[]}
 */
export function parseCSV(text) {
  // Normalize line endings, strip BOM
  text = text.replace(/^\uFEFF/, '');
  const lines = text.split(/\r\n|\n|\r/).filter(l => l.trim().length > 0);
  if (lines.length === 0) throw new Error('CSV file is empty.');

  const delim = detectDelimiter(lines[0]);
  let startIdx = 0;
  let cols = mapHeader(lines[0].split(delim));

  const firstCells = lines[0].split(delim).map(stripQuotes);
  const hasHeader = looksLikeHeader(firstCells);

  if (hasHeader) {
    startIdx = 1;
    if (Object.keys(cols).length === 0) {
      // header present but unrecognized labels -> fall back to positional guess below
      cols = {};
    }
  } else {
    cols = {}; // positional parsing
  }

  // Positional fallback guesses for common MT5 export layouts:
  // DATE,TIME,OPEN,HIGH,LOW,CLOSE,TICKVOL,VOL,SPREAD  (9 cols)
  // DATE,TIME,OPEN,HIGH,LOW,CLOSE,VOLUME (7 cols)
  // DATETIME,OPEN,HIGH,LOW,CLOSE,VOLUME (6 cols)
  if (Object.keys(cols).length === 0) {
    const sampleCells = lines[startIdx].split(delim);
    if (sampleCells.length >= 9) {
      cols = { date: 0, time: 1, open: 2, high: 3, low: 4, close: 5, volume: 6 };
    } else if (sampleCells.length === 7) {
      cols = { date: 0, time: 1, open: 2, high: 3, low: 4, close: 5, volume: 6 };
    } else if (sampleCells.length === 6) {
      cols = { datetime: 0, open: 1, high: 2, low: 3, close: 4, volume: 5 };
    } else if (sampleCells.length === 5) {
      cols = { datetime: 0, open: 1, high: 2, low: 3, close: 4 };
    } else {
      throw new Error('Unrecognized CSV column layout — expected MT5-style OHLC export.');
    }
  }

  if (cols.open === undefined || cols.high === undefined || cols.low === undefined || cols.close === undefined) {
    throw new Error('Could not locate Open/High/Low/Close columns in CSV.');
  }

  const candles = [];
  for (let i = startIdx; i < lines.length; i++) {
    const cells = lines[i].split(delim);
    if (cells.length < 4) continue;

    let time;
    if (cols.datetime !== undefined) {
      const raw = stripQuotes(cells[cols.datetime]);
      const [dPart, tPart] = raw.split(/[ T]/);
      time = parseDateTime(dPart, tPart || '');
    } else {
      time = parseDateTime(cells[cols.date], cols.time !== undefined ? cells[cols.time] : '');
    }
    if (time === null) continue;

    const open = parseFloat(cells[cols.open]);
    const high = parseFloat(cells[cols.high]);
    const low = parseFloat(cells[cols.low]);
    const close = parseFloat(cells[cols.close]);
    if ([open, high, low, close].some(v => Number.isNaN(v))) continue;

    const volume = cols.volume !== undefined ? parseFloat(cells[cols.volume]) || 0 : 0;

    candles.push({ time, open, high, low, close, volume });
  }

  if (candles.length === 0) throw new Error('No valid OHLC rows found in CSV.');

  candles.sort((a, b) => a.time - b.time);

  // Collapse duplicate timestamps (keep last occurrence)
  const deduped = [];
  for (const c of candles) {
    if (deduped.length > 0 && deduped[deduped.length - 1].time === c.time) {
      deduped[deduped.length - 1] = c;
    } else {
      deduped.push(c);
    }
  }

  return deduped;
}

/**
 * Read a File object and resolve with parsed candles.
 * @param {File} file
 * @returns {Promise<Candle[]>}
 */
export function loadCSVFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const candles = parseCSV(reader.result);
        resolve(candles);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file.'));
    reader.readAsText(file);
  });
}
